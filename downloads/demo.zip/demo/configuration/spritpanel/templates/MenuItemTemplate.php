

$_SPRIT['SPRITPANEL_MENU'][] = Array(
		'id' => '{{id}}',
		'index' => {{index}},
		'name' => '{{name}}',
		'URL' => '{{URL}}',
		'editable' => {{editable}},
		'parentId' => '{{parentId}}',
		'visible' => {{visible}}
);